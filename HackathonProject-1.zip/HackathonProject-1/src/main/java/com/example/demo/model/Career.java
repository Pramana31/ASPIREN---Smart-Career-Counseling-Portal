package com.example.demo.model;

import jakarta.persistence.*;

@Entity
@Table(name = "careers")
public class Career {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Works perfectly for PostgreSQL
    private Long id;

    @Column(name = "field", nullable = false, length = 100)
    private String field;

    @Column(name = "title", nullable = false, length = 150)
    private String title;

    @Column(name = "eligibility", columnDefinition = "TEXT")
    private String eligibility;

    @Column(name = "entrance_exam", columnDefinition = "TEXT")
    private String entranceExam;

    @Column(name = "scope", columnDefinition = "TEXT")
    private String scope;

    @Column(name = "top_colleges", columnDefinition = "TEXT")
    private String topColleges;

    // Getters & Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getField() { return field; }
    public void setField(String field) { this.field = field; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getEligibility() { return eligibility; }
    public void setEligibility(String eligibility) { this.eligibility = eligibility; }

    public String getEntranceExam() { return entranceExam; }
    public void setEntranceExam(String entranceExam) { this.entranceExam = entranceExam; }

    public String getScope() { return scope; }
    public void setScope(String scope) { this.scope = scope; }

    public String getTopColleges() { return topColleges; }
    public void setTopColleges(String topColleges) { this.topColleges = topColleges; }
}
