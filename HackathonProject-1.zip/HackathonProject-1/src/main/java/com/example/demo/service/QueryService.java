package com.example.demo.service;

import com.example.demo.model.Query;
import com.example.demo.repository.QueryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class QueryService {

    @Autowired
    private QueryRepository queryRepository;

    public List<Query> getAllQueries() {
        return queryRepository.findAllByOrderByCreatedAtDesc();
    }

    public List<Query> getPendingQueries() {
        return queryRepository.findByStatusOrderByCreatedAtDesc("Pending");
    }

    public List<Query> getCounselorAnsweredQueries(Long counselorId) {
        return queryRepository.findByCounselorIdOrderByAnsweredAtDesc(counselorId);
    }

    public List<Query> getStudentQueries(Long studentId) {
        return queryRepository.findByStudentIdOrderByCreatedAtDesc(studentId);
    }

    public Query getQueryById(Long id) {
        return queryRepository.findById(id).orElse(null);
    }

    public Query submitQuery(Query query) {
        query.setStatus("Pending");
        query.setCreatedAt(LocalDateTime.now());
        return queryRepository.save(query);
    }

    public Query answerQuery(Long queryId, String answer, Long counselorId) {
        Query query = queryRepository.findById(queryId).orElse(null);
        if (query != null) {
            query.setAnswer(answer);
            query.setCounselorId(counselorId);
            query.setStatus("Answered");
            query.setAnsweredAt(LocalDateTime.now());
            return queryRepository.save(query);
        }
        return null;
    }
}