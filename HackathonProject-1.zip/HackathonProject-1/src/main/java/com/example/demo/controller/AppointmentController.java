package com.example.demo.controller;

import com.example.demo.model.Appointment;
import com.example.demo.service.AppointmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@Controller
@RequestMapping("/appointments")
public class AppointmentController {

    @Autowired
    private AppointmentService appointmentService;

    // ✅ Show form for booking an appointment
    @GetMapping("/book")
    public String showBookingForm(Model model) {
        model.addAttribute("appointment", new Appointment());
        return "book-appointment"; // Thymeleaf template
    }

    // ✅ Book an appointment
    @PostMapping("/book")
    public String bookAppointment(@ModelAttribute Appointment appointment, Model model) {
        appointmentService.bookAppointment(appointment);
        return "redirect:/appointments/student/" + appointment.getStudentId();
    }

    // ✅ Student view
    @GetMapping("/student/{studentId}")
    public String viewStudentAppointments(@PathVariable Long studentId, Model model) {
        List<Appointment> appointments = appointmentService.getByStudent(studentId);
        model.addAttribute("appointments", appointments);
        return "student-appointments";
    }

    // ✅ Counselor view
    @GetMapping("/counselor/{counselorId}")
    public String viewCounselorAppointments(@PathVariable Long counselorId, Model model) {
        List<Appointment> appointments = appointmentService.getByCounselor(counselorId);
        model.addAttribute("appointments", appointments);
        return "counselor-appointments";
    }

    // ✅ Update appointment status (Completed / Cancelled)
    @PostMapping("/update-status/{id}")
    public String updateStatus(@PathVariable Long id, @RequestParam String status) {
        Appointment updated = appointmentService.updateStatus(id, status);
        if (updated != null) {
            return "redirect:/appointments/counselor/" + updated.getCounselorId();
        }
        return "redirect:/error";
    }
}
