package com.example.demo.model;

import jakarta.persistence.*;

@Entity
@Table(name = "assessments")
public class Assessment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Works well with PostgreSQL SERIAL / IDENTITY
    private Long id;

    @Column(name = "student_id", nullable = false)
    private Long studentId;

    @Column(name = "science_score", nullable = false)
    private int scienceScore;

    @Column(name = "arts_score", nullable = false)
    private int artsScore;

    @Column(name = "commerce_score", nullable = false)
    private int commerceScore;

    @Column(name = "recommendation", length = 255)
    private String recommendation;

    // Getters & Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getStudentId() { return studentId; }
    public void setStudentId(Long studentId) { this.studentId = studentId; }

    public int getScienceScore() { return scienceScore; }
    public void setScienceScore(int scienceScore) { this.scienceScore = scienceScore; }

    public int getArtsScore() { return artsScore; }
    public void setArtsScore(int artsScore) { this.artsScore = artsScore; }

    public int getCommerceScore() { return commerceScore; }
    public void setCommerceScore(int commerceScore) { this.commerceScore = commerceScore; }

    public String getRecommendation() { return recommendation; }
    public void setRecommendation(String recommendation) { this.recommendation = recommendation; }
}
