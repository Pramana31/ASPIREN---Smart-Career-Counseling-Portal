package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MainController {

    // Add these mappings to your existing MainController
    @GetMapping("/students")
    public String redirectStudents() {
        return "redirect:/stats/students";
    }

    @GetMapping("/careers")
    public String redirectCareers() {
        return "redirect:/stats/careers";
    }

    @GetMapping("/success-rate")
    public String redirectSuccessRate() {
        return "redirect:/stats/success-rate";
    }

    @GetMapping("/colleges")
    public String redirectColleges() {
        return "redirect:/stats/colleges";
    }

    @GetMapping("/scholarships")
    public String redirectScholarships() {
        return "redirect:/stats/scholarships";
    }

    @GetMapping("/countries")
    public String redirectCountries() {
        return "redirect:/stats/countries";
    }
    
 // Add these methods to your MainController
    @GetMapping("/assessment/start")
    public String redirectAssessment() {
        return "redirect:/student/assessment";
    }

    @GetMapping("/careers/explore")
    public String redirectCareersExplore() {
        return "redirect:/student/careers";
    }
}