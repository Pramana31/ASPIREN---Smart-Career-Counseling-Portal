package com.example.demo.service;

import com.example.demo.model.Student;
import com.example.demo.repository.StudentRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class StudentService {
    
    private final StudentRepository studentRepo;
    private final PasswordEncoder passwordEncoder;
    
    public StudentService(StudentRepository studentRepo, PasswordEncoder passwordEncoder) {
        this.studentRepo = studentRepo;
        this.passwordEncoder = passwordEncoder;
    }
    
    public Student register(Student student) {
        Student existingStudent = studentRepo.findByEmail(student.getEmail());
        if (existingStudent != null) {
            throw new RuntimeException("Email already registered");
        }
        
        String encodedPassword = passwordEncoder.encode(student.getPassword());
        student.setPassword(encodedPassword);
        
        return studentRepo.save(student);
    }

    public Student login(String email, String password) {
        Student student = studentRepo.findByEmail(email);
        if (student != null && passwordEncoder.matches(password, student.getPassword())) {
            return student;
        }
        return null;
    }

    public List<Student> getAllStudents() {
        return studentRepo.findAll();
    }

    public Student getStudentById(Long id) {
        Optional<Student> student = studentRepo.findById(id);
        return student.orElseThrow(() -> new RuntimeException("Student not found"));
    }

    public Student updateStudent(Student student) {
        Student existingStudent = getStudentById(student.getId());
        
        existingStudent.setName(student.getName());
        existingStudent.setEmail(student.getEmail());
        existingStudent.setAge(student.getAge());
        existingStudent.setInterests(student.getInterests());
        existingStudent.setStrengths(student.getStrengths());
        
        if (student.getPassword() != null && !student.getPassword().isEmpty()) {
            String encodedPassword = passwordEncoder.encode(student.getPassword());
            existingStudent.setPassword(encodedPassword);
        }
        
        return studentRepo.save(existingStudent);
    }
}