package com.example.demo.controller;

import com.example.demo.model.Counselor;
import com.example.demo.model.Query;
import com.example.demo.service.CounselorService;
import com.example.demo.service.QueryService;

import jakarta.servlet.http.HttpSession;

import com.example.demo.service.AppointmentService;
import com.example.demo.model.Appointment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/counselor")
public class CounselorController {

    @Autowired 
    private CounselorService counselorService;

    @Autowired 
    private AppointmentService appointmentService;
    
    @Autowired
    private QueryService queryService;

    @GetMapping("/")
    public String home(Model model) {
        model.addAttribute("message", "Welcome to Spring Boot Web App using STS!");
        return "login";
    }

    // ===== Counselor Registration =====
    @GetMapping("/register")
    public String showRegisterForm(Model model) {
        model.addAttribute("counselor", new Counselor());
        return "counselor-register";
    }

    @PostMapping("/register")
    public String register(@ModelAttribute Counselor counselor, Model model) {
        try {
            counselorService.register(counselor);
            model.addAttribute("message", "Counselor registered successfully!");
            return "counselor-login";
        } catch (RuntimeException e) {
            model.addAttribute("error", e.getMessage());
            return "counselor-register";
        }
    }

    // ===== Counselor Login =====
    @GetMapping("/login")
    public String showLoginForm(Model model) {
        model.addAttribute("counselor", new Counselor());
        return "counselor-login";
    }

    @PostMapping("/login")
    public String login(@ModelAttribute Counselor counselor, Model model, HttpSession session) {
        Counselor loggedInCounselor = counselorService.login(counselor.getEmail(), counselor.getPassword());
        if (loggedInCounselor != null) {
            session.setAttribute("counselor", loggedInCounselor); // Set session
            model.addAttribute("counselor", loggedInCounselor);
            return "counselor-dashboard";
        } else {
            model.addAttribute("error", "Invalid email or password");
            return "counselor-login";
        }
    }

    // ===== Profile Management =====
    @GetMapping("/profile")
    public String showProfile(HttpSession session, Model model) {
        Counselor counselor = (Counselor) session.getAttribute("counselor");
        if (counselor == null) {
            return "redirect:/counselor/login";
        }
        model.addAttribute("counselor", counselor);
        return "counselor-profile";
    }

    @PostMapping("/profile/update")
    public String updateProfile(@ModelAttribute Counselor counselor, HttpSession session, Model model) {
        try {
            Counselor updatedCounselor = counselorService.updateCounselor(counselor);
            session.setAttribute("counselor", updatedCounselor); // Update session
            model.addAttribute("counselor", updatedCounselor);
            model.addAttribute("message", "Profile updated successfully!");
            return "counselor-profile";
        } catch (RuntimeException e) {
            model.addAttribute("error", "Failed to update profile: " + e.getMessage());
            model.addAttribute("counselor", counselor);
            return "counselor-profile";
        }
    }

    // ===== View Counselor Appointments =====
    @GetMapping("/appointments/{id}")
    public String viewAppointments(@PathVariable Long id, Model model) {
        List<Appointment> appointments = appointmentService.getByCounselor(id);
        model.addAttribute("appointments", appointments);
        return "counselor-appointments";
    }

    // ===== Dashboard =====
    @GetMapping("/dashboard")
    public String showDashboard(HttpSession session, Model model) {
        Counselor counselor = (Counselor) session.getAttribute("counselor");
        if (counselor == null) {
            return "redirect:/counselor/login";
        }
        model.addAttribute("counselor", counselor);
        return "counselor-dashboard";
    }

    // ===== Query Management =====
    @GetMapping("/queries")
    public String viewAllQueries(HttpSession session, Model model) {
        Counselor counselor = (Counselor) session.getAttribute("counselor");
        if (counselor == null) {
            return "redirect:/counselor/login";
        }
        
        List<Query> queries = queryService.getAllQueries();
        model.addAttribute("queries", queries);
        model.addAttribute("counselor", counselor);
        return "counselor-queries";
    }

    @GetMapping("/queries/pending")
    public String viewPendingQueries(HttpSession session, Model model) {
        Counselor counselor = (Counselor) session.getAttribute("counselor");
        if (counselor == null) {
            return "redirect:/counselor/login";
        }
        
        List<Query> pendingQueries = queryService.getPendingQueries();
        model.addAttribute("queries", pendingQueries);
        model.addAttribute("counselor", counselor);
        return "counselor-pending-queries";
    }

    @GetMapping("/queries/answered")
    public String viewAnsweredQueries(HttpSession session, Model model) {
        Counselor counselor = (Counselor) session.getAttribute("counselor");
        if (counselor == null) {
            return "redirect:/counselor/login";
        }
        
        List<Query> answeredQueries = queryService.getCounselorAnsweredQueries(counselor.getId());
        model.addAttribute("queries", answeredQueries);
        model.addAttribute("counselor", counselor);
        return "counselor-answered-queries";
    }

    @GetMapping("/query/answer/{id}")
    public String showAnswerForm(@PathVariable Long id, HttpSession session, Model model) {
        Counselor counselor = (Counselor) session.getAttribute("counselor");
        if (counselor == null) {
            return "redirect:/counselor/login";
        }
        
        Query query = queryService.getQueryById(id);
        if (query == null) {
            model.addAttribute("error", "Query not found");
            return "redirect:/counselor/queries";
        }
        
        model.addAttribute("query", query);
        model.addAttribute("counselor", counselor);
        return "answer-query";
    }

    @PostMapping("/query/answer/{id}")
    public String answerQuery(@PathVariable Long id, 
                             @RequestParam String answer,
                             HttpSession session,
                             Model model) {
        Counselor counselor = (Counselor) session.getAttribute("counselor");
        if (counselor == null) {
            return "redirect:/counselor/login";
        }
        
        Query answeredQuery = queryService.answerQuery(id, answer, counselor.getId());
        if (answeredQuery != null) {
            model.addAttribute("message", "Query answered successfully!");
        } else {
            model.addAttribute("error", "Failed to answer query");
        }
        
        return "redirect:/counselor/queries";
    }

    // ===== Manage Availability =====
    @GetMapping("/availability")
    public String showAvailabilityForm(HttpSession session, Model model) {
        Counselor counselor = (Counselor) session.getAttribute("counselor");
        if (counselor == null) {
            return "redirect:/counselor/login";
        }
        
        model.addAttribute("counselor", counselor);
        return "counselor-availability";
    }

    @PostMapping("/availability/update")
    public String updateAvailability(@RequestParam String availableTimeSlots, 
                                   HttpSession session, 
                                   Model model) {
        Counselor counselor = (Counselor) session.getAttribute("counselor");
        if (counselor == null) {
            return "redirect:/counselor/login";
        }
        
        try {
            counselor.setAvailableTimeSlots(availableTimeSlots);
            Counselor updatedCounselor = counselorService.updateCounselor(counselor);
            session.setAttribute("counselor", updatedCounselor);
            model.addAttribute("message", "Availability updated successfully!");
            model.addAttribute("counselor", updatedCounselor);
        } catch (RuntimeException e) {
            model.addAttribute("error", "Failed to update availability: " + e.getMessage());
        }
        
        return "counselor-availability";
    }
}