package com.example.demo.repository;

import com.example.demo.model.StudentInterest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface StudentInterestRepository extends JpaRepository<StudentInterest, Long> {

    // Find latest interest form by student
    Optional<StudentInterest> findTopByStudentIdOrderByCreatedAtDesc(Long studentId);

    // Find all interest forms by student
    List<StudentInterest> findByStudentIdOrderByCreatedAtDesc(Long studentId);

    // Check if student has submitted interest form
    boolean existsByStudentId(Long studentId);
}