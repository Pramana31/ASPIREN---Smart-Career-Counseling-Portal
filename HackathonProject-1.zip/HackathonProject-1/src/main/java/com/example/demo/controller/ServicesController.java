package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/services")
public class ServicesController {

    @GetMapping("/colleges/find")
    public String collegeFinder(Model model) {
        model.addAttribute("pageTitle", "College Finder");
        return "services-colleges";
    }

    @GetMapping("/scholarships")
    public String scholarshipFinder(Model model) {
        model.addAttribute("pageTitle", "Scholarship Finder");
        return "services-scholarships";
    }

    @GetMapping("/courses")
    public String skillCourses(Model model) {
        model.addAttribute("pageTitle", "Skill Development Courses");
        return "services-courses";
    }

    @GetMapping("/exams")
    public String examPreparation(Model model) {
        model.addAttribute("pageTitle", "Competitive Exam Preparation");
        return "services-exams";
    }
}