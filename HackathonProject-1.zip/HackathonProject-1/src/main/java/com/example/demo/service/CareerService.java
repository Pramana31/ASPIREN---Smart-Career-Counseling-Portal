package com.example.demo.service;

import com.example.demo.model.Career;
import com.example.demo.repository.CareerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CareerService {

    @Autowired
    private CareerRepository careerRepository;

    public List<Career> getAllCareers() {
        return careerRepository.findAll();
    }

    public List<Career> getCareersByField(String field) {
        return careerRepository.findByFieldIgnoreCase(field);
    }

    public List<Career> searchCareers(String query) {
        if (query == null || query.trim().isEmpty()) {
            return careerRepository.findAll();
        }
        return careerRepository.searchCareers(query.trim());
    }

    public List<Career> searchCareersByField(String field, String query) {
        if (query == null || query.trim().isEmpty()) {
            return careerRepository.findByFieldIgnoreCase(field);
        }
        return careerRepository.searchCareersByField(field, query.trim());
    }

    public Career getCareerById(Long id) {
        return careerRepository.findById(id).orElse(null);
    }

	public List<Career> getRecommendedCareers(String recommendation) {
		// TODO Auto-generated method stub
		return null;
	}
}