package com.example.demo.repository;

import com.example.demo.model.Query;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface QueryRepository extends JpaRepository<Query, Long> {

    // Find queries by student ID
    List<Query> findByStudentIdOrderByCreatedAtDesc(Long studentId);

    // Find pending queries for counselors
    List<Query> findByStatusOrderByCreatedAtDesc(String status);

    // Find queries answered by a specific counselor
    List<Query> findByCounselorIdOrderByAnsweredAtDesc(Long counselorId);

    // Find all queries for counselor dashboard
    List<Query> findAllByOrderByCreatedAtDesc();
}