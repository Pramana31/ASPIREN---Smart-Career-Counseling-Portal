package com.example.demo.service;

import com.example.demo.model.Assessment;
import com.example.demo.repository.AssessmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class AssessmentService {
    
    @Autowired
    private AssessmentRepository assessmentRepo;

    public Assessment saveAssessment(Assessment assessment) {
        // Enhanced recommendation logic
        String recommendation = calculateRecommendation(assessment);
        assessment.setRecommendation(recommendation);
        return assessmentRepo.save(assessment);
    }

    public Assessment getLatest(Long studentId) {
        return assessmentRepo.findTopByStudentIdOrderByIdDesc(studentId);
    }

    public List<Assessment> getStudentAssessments(Long studentId) {
        return assessmentRepo.findByStudentIdOrderByIdDesc(studentId);
    }

    public boolean hasAssessment(Long studentId) {
        return assessmentRepo.existsByStudentId(studentId);
    }

    private String calculateRecommendation(Assessment assessment) {
        int science = assessment.getScienceScore();
        int arts = assessment.getArtsScore();
        int commerce = assessment.getCommerceScore();

        if (science >= arts && science >= commerce) {
            return "Science Stream - Engineering, Medicine, Research, Technology";
        } else if (commerce >= science && commerce >= arts) {
            return "Commerce Stream - Business, Finance, Accounting, Management";
        } else {
            return "Arts Stream - Humanities, Social Sciences, Creative Arts, Literature";
        }
    }
}