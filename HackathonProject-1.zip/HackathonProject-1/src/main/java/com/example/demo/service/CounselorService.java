package com.example.demo.service;

import com.example.demo.model.Counselor;
import com.example.demo.repository.CounselorRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class CounselorService {
    
    private final CounselorRepository counselorRepo;
    private final PasswordEncoder passwordEncoder;
    
    public CounselorService(CounselorRepository counselorRepo, PasswordEncoder passwordEncoder) {
        this.counselorRepo = counselorRepo;
        this.passwordEncoder = passwordEncoder;
    }

    public Counselor register(Counselor counselor) {
        Counselor existingCounselor = counselorRepo.findByEmail(counselor.getEmail());
        if (existingCounselor != null) {
            throw new RuntimeException("Email already registered");
        }
        
        String encodedPassword = passwordEncoder.encode(counselor.getPassword());
        counselor.setPassword(encodedPassword);
        
        return counselorRepo.save(counselor);
    }

    public Counselor login(String email, String password) {
        Counselor counselor = counselorRepo.findByEmail(email);
        if (counselor != null && passwordEncoder.matches(password, counselor.getPassword())) {
            return counselor;
        }
        return null;
    }

    public List<Counselor> getAll() {
        return counselorRepo.findAll();
    }

    public Counselor getCounselorById(Long id) {
        Optional<Counselor> counselor = counselorRepo.findById(id);
        return counselor.orElseThrow(() -> new RuntimeException("Counselor not found"));
    }

    public Counselor updateCounselor(Counselor counselor) {
        Counselor existingCounselor = counselorRepo.findById(counselor.getId()).orElse(null);
        if (existingCounselor != null) {
            existingCounselor.setName(counselor.getName());
            existingCounselor.setSpecialization(counselor.getSpecialization());
            existingCounselor.setEmail(counselor.getEmail());
            existingCounselor.setAvailableTimeSlots(counselor.getAvailableTimeSlots());
            return counselorRepo.save(existingCounselor);
        }
        throw new RuntimeException("Counselor not found");
    }
}