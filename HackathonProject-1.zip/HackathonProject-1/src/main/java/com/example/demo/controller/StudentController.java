package com.example.demo.controller;

import com.example.demo.model.Student;
import com.example.demo.model.Appointment;
import com.example.demo.model.Assessment;
import com.example.demo.model.Career;
import com.example.demo.model.Query;
import com.example.demo.service.StudentService;

import jakarta.servlet.http.HttpSession;

import com.example.demo.service.AppointmentService;
import com.example.demo.service.AssessmentService;
import com.example.demo.service.CareerService;
import com.example.demo.service.QueryService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/student")
public class StudentController {

    @Autowired 
    private StudentService studentService;

    @Autowired 
    private AppointmentService appointmentService;
    
    @GetMapping("/")
    public String home(Model model) {
        model.addAttribute("message", "Welcome to Spring Boot Web App using STS!");
        return "login";
    }

    // ===== Register =====
    @GetMapping("/register")
    public String showRegisterForm(Model model) {
        model.addAttribute("student", new Student());
        return "student-register";
    }

    @PostMapping("/register")
    public String register(@ModelAttribute Student student, Model model) {
        try {
            studentService.register(student);
            model.addAttribute("message", "Registration Successful!");
            return "student-login";
        } catch (RuntimeException e) {
            model.addAttribute("error", e.getMessage());
            return "student-register";
        }
    }

    // ===== Login =====
    @GetMapping("/login")
    public String showLoginForm(Model model) {
        model.addAttribute("student", new Student());
        return "student-login";
    }

    @PostMapping("/login")
    public String login(@ModelAttribute Student student, Model model, HttpSession session) {
        Student loggedInStudent = studentService.login(student.getEmail(), student.getPassword());
        if (loggedInStudent != null) {
            session.setAttribute("student", loggedInStudent); // Set session
            model.addAttribute("student", loggedInStudent);
            return "student-dashboard";
        } else {
            model.addAttribute("error", "Invalid email or password");
            return "student-login";
        }
    }

    // ===== Dashboard =====
    @GetMapping("/dashboard")
    public String showDashboard(HttpSession session, Model model) {
        // Get student from session (you need to set this during login)
        Student student = (Student) session.getAttribute("student");
        if (student == null) {
            return "redirect:/student/login";
        }
        model.addAttribute("student", student);
        return "student-dashboard";
    }
    
    // ===== Profile Management =====
    @GetMapping("/profile")
    public String showProfile(HttpSession session, Model model) {
        Student student = (Student) session.getAttribute("student");
        if (student == null) {
            return "redirect:/student/login";
        }
        model.addAttribute("student", student);
        return "student-profile";
    }

    @PostMapping("/profile/update")
    public String updateProfile(@ModelAttribute Student student, HttpSession session, Model model) {
        try {
            Student updatedStudent = studentService.updateStudent(student);
            session.setAttribute("student", updatedStudent); // Update session
            model.addAttribute("student", updatedStudent);
            model.addAttribute("message", "Profile updated successfully!");
            return "student-profile";
        } catch (RuntimeException e) {
            model.addAttribute("error", "Failed to update profile: " + e.getMessage());
            model.addAttribute("student", student);
            return "student-profile";
        }
    }

    // ===== View Appointments =====
    @GetMapping("/appointments/{id}")
    public String viewAppointments(@PathVariable Long id, Model model) {
        List<Appointment> appointments = appointmentService.getByStudent(id);
        model.addAttribute("appointments", appointments);
        return "student-appointments";
    }
    


    
    @Autowired
    private AssessmentService assessmentService;

    @Autowired
    private CareerService careerService;

    @Autowired
    private QueryService queryService;

    // ===== Assessment =====
    @GetMapping("/assessment")
    public String showAssessmentForm(HttpSession session, Model model) {
        Student student = (Student) session.getAttribute("student");
        if (student == null) {
            return "redirect:/student/login";
        }
        model.addAttribute("assessment", new Assessment());
        model.addAttribute("student", student);
        return "assessment-form";
    }

    @PostMapping("/assessment/submit")
    public String submitAssessment(@ModelAttribute Assessment assessment, HttpSession session, Model model) {
        Student student = (Student) session.getAttribute("student");
        if (student == null) {
            return "redirect:/student/login";
        }
        
        assessment.setStudentId(student.getId());
        Assessment savedAssessment = assessmentService.saveAssessment(assessment);
        model.addAttribute("assessment", savedAssessment);
        model.addAttribute("student", student);
        return "assessment-result";
    }

    @GetMapping("/assessment/result")
    public String viewAssessmentResult(HttpSession session, Model model) {
        Student student = (Student) session.getAttribute("student");
        if (student == null) {
            return "redirect:/student/login";
        }
        
        Assessment assessment = assessmentService.getLatest(student.getId());
        if (assessment != null) {
            List<Career> recommendedCareers = careerService.getRecommendedCareers(assessment.getRecommendation());
            model.addAttribute("assessment", assessment);
            model.addAttribute("careers", recommendedCareers);
        }
        model.addAttribute("student", student);
        return "assessment-result";
    }

    // ===== Career Information =====
    @GetMapping("/careers")
    public String viewCareers(HttpSession session, Model model) {
        Student student = (Student) session.getAttribute("student");
        if (student == null) {
            return "redirect:/student/login";
        }
        
        List<Career> careers = careerService.getAllCareers();
        model.addAttribute("careers", careers);
        model.addAttribute("student", student);
        return "career-information";
    }

    @GetMapping("/careers/{field}")
    public String viewCareersByField(@PathVariable String field, HttpSession session, Model model) {
        Student student = (Student) session.getAttribute("student");
        if (student == null) {
            return "redirect:/student/login";
        }
        
        List<Career> careers = careerService.getCareersByField(field);
        model.addAttribute("careers", careers);
        model.addAttribute("field", field);
        model.addAttribute("student", student);
        return "career-information";
    }

    // ===== Query System =====
    @GetMapping("/query")
    public String showQueryForm(HttpSession session, Model model) {
        Student student = (Student) session.getAttribute("student");
        if (student == null) {
            return "redirect:/student/login";
        }
        
        model.addAttribute("query", new Query());
        model.addAttribute("student", student);
        return "query-form";
    }

    @PostMapping("/query/submit")
    public String submitQuery(@ModelAttribute Query query, HttpSession session, Model model) {
        Student student = (Student) session.getAttribute("student");
        if (student == null) {
            return "redirect:/student/login";
        }
        
        query.setStudentId(student.getId());
        query.setStudentName(student.getName());
        Query savedQuery = queryService.submitQuery(query);
        
        model.addAttribute("message", "Your query has been submitted successfully!");
        model.addAttribute("student", student);
        return "redirect:/student/queries";
    }

    @GetMapping("/queries")
    public String viewMyQueries(HttpSession session, Model model) {
        Student student = (Student) session.getAttribute("student");
        if (student == null) {
            return "redirect:/student/login";
        }
        
        List<Query> queries = queryService.getStudentQueries(student.getId());
        model.addAttribute("queries", queries);
        model.addAttribute("student", student);
        return "student-queries";
    }
 
}