package com.example.demo.repository;

import com.example.demo.model.Counselor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CounselorRepository extends JpaRepository<Counselor, Long> {

    // Counselor login verification
    Counselor findByEmailAndPassword(String email, String password);

    // Find by email for duplicate check
    Counselor findByEmail(String email);

    // Find by specialization (optional feature)
    Counselor findBySpecialization(String specialization);
}