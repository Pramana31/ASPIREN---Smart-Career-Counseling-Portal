package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/stats")
public class StatisticsController {

    @GetMapping("/students")
    public String studentsStats(Model model) {
        model.addAttribute("pageTitle", "Students Statistics");
        model.addAttribute("stats", new String[]{
            "10,000+ Students Guided Successfully",
            "95% Student Satisfaction Rate",
            "500+ Career Paths Chosen",
            "89% Higher Admission Success Rate"
        });
        return "stats-students";
    }

    @GetMapping("/careers")
    public String careerExperts(Model model) {
        model.addAttribute("pageTitle", "Career Experts");
        model.addAttribute("experts", new String[]{
            "500+ Certified Career Counselors",
            "100+ Industry Professionals",
            "50+ Psychometric Experts",
            "25+ International Education Consultants"
        });
        return "stats-careers";
    }

    @GetMapping("/success-rate")
    public String successRate(Model model) {
        model.addAttribute("pageTitle", "Success Metrics");
        model.addAttribute("metrics", new String[]{
            "Overall Success Rate: 95%",
            "College Admission Success: 92%",
            "Career Clarity Achievement: 96%",
            "Student Satisfaction: 94%"
        });
        return "stats-success";
    }

    @GetMapping("/colleges")
    public String partnerColleges(Model model) {
        model.addAttribute("pageTitle", "Partner Colleges");
        model.addAttribute("colleges", new String[]{
            "50+ Partner Institutions",
            "15+ International Universities",
            "35+ Indian Premier Colleges",
            "1000+ Courses Available"
        });
        return "stats-colleges";
    }

    @GetMapping("/scholarships")
    public String scholarships(Model model) {
        model.addAttribute("pageTitle", "Scholarships Secured");
        model.addAttribute("scholarships", new String[]{
            "₹5 Crore+ Total Scholarships",
            "2000+ Students Benefited",
            "Merit-based Scholarships: 60%",
            "Need-based Scholarships: 40%"
        });
        return "stats-scholarships";
    }

    @GetMapping("/countries")
    public String countriesReached(Model model) {
        model.addAttribute("pageTitle", "Global Reach");
        model.addAttribute("countries", new String[]{
            "25+ Countries Worldwide",
            "5 Continents Coverage",
            "International Student Support",
            "Global Education Partnerships"
        });
        return "stats-countries";
    }
}