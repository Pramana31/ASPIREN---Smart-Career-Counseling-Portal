package com.example.demo.repository;

import com.example.demo.model.Career;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CareerRepository extends JpaRepository<Career, Long> {

    // Search by career title or field
    List<Career> findByTitleContainingIgnoreCase(String title);

    // Get careers by domain (e.g., "Engineering", "Medicine")
    List<Career> findByFieldIgnoreCase(String field);

    // Enhanced search across multiple fields
    @Query("SELECT c FROM Career c WHERE " +
           "LOWER(c.title) LIKE LOWER(CONCAT('%', :query, '%')) OR " +
           "LOWER(c.field) LIKE LOWER(CONCAT('%', :query, '%')) OR " +
           "LOWER(c.scope) LIKE LOWER(CONCAT('%', :query, '%')) OR " +
           "LOWER(c.eligibility) LIKE LOWER(CONCAT('%', :query, '%')) OR " +
           "LOWER(c.entranceExam) LIKE LOWER(CONCAT('%', :query, '%')) OR " +
           "LOWER(c.topColleges) LIKE LOWER(CONCAT('%', :query, '%'))")
    List<Career> searchCareers(@Param("query") String query);

    // Search by field with additional search term
    @Query("SELECT c FROM Career c WHERE " +
           "c.field = :field AND " +
           "(LOWER(c.title) LIKE LOWER(CONCAT('%', :query, '%')) OR " +
           "LOWER(c.scope) LIKE LOWER(CONCAT('%', :query, '%')))")
    List<Career> searchCareersByField(@Param("field") String field, @Param("query") String query);
}