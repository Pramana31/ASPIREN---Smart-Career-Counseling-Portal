package com.example.demo.repository;

import com.example.demo.model.Assessment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface AssessmentRepository extends JpaRepository<Assessment, Long> {

    // Get latest assessment for a student
    Assessment findTopByStudentIdOrderByIdDesc(Long studentId);

    // Get all assessments for a student
    List<Assessment> findByStudentIdOrderByIdDesc(Long studentId);
    
    // Custom query to check if student has any assessments
    @Query("SELECT COUNT(a) > 0 FROM Assessment a WHERE a.studentId = :studentId")
    boolean existsByStudentId(Long studentId);
}