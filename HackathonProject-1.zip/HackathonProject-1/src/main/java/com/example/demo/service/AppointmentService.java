package com.example.demo.service;

import com.example.demo.model.Appointment;
import com.example.demo.repository.AppointmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AppointmentService {

    @Autowired
    private AppointmentRepository appointmentRepo;

    public Appointment bookAppointment(Appointment appointment) {
        appointment.setStatus("Scheduled");
        return appointmentRepo.save(appointment);
    }

    public List<Appointment> getByStudent(Long studentId) {
        return appointmentRepo.findByStudentId(studentId);
    }

    public List<Appointment> getByCounselor(Long counselorId) {
        return appointmentRepo.findByCounselorId(counselorId);
    }

    public Appointment getById(Long id) {
        return appointmentRepo.findById(id).orElse(null);
    }

    public Appointment updateStatus(Long id, String status) {
        Appointment appointment = getById(id);
        if (appointment != null) {
            appointment.setStatus(status);
            return appointmentRepo.save(appointment);
        }
        return null;
    }
}
